import ntpath
import pickle
import re

import numpy as np


def path_leaf(path):
    head, tail = ntpath.split(path)
    return tail or ntpath.basename(head)


def subtract(a, b):
    return "".join(a.rsplit(b))


def apply_fun(dict_: dict, fun, **kwargs):
    transformed_dict = dict((k, fun(v, **kwargs)) for k, v in dict_.items())
    return transformed_dict


def replace_global_missing_features_with_empty(df):
    df = df.replace(np.nan, '', regex=True).fillna("")
    return df


def drop_if_exists(df, cols):
    for col in cols:
        if col in df.columns:
            df = df.drop(col, axis=1)
    return df


def text_cleaner(text):
    rules = [
        {r'>\s+': u'>'},  # remove spaces after a tag opens or closes
        {r'\s+': u' '},  # replace consecutive spaces
        {r'\s*<br\s*/?>\s*': u'\n'},  # newline after a <br>
        {r'</(div)\s*>\s*': u'\n'},  # newline after </p> and </div> and <h1/>...
        {r'</(p|h\d)\s*>\s*': u'\n\n'},  # newline after </p> and </div> and <h1/>...
        {r'<head>.*<\s*(/head|body)[^>]*>': u''},  # remove <head> to </head>
        {r'<a\s+href="([^"]+)"[^>]*>.*</a>': r'\1'},  # show links instead of texts
        {r'[ \t]*<[^<]*?/?>': u''},  # remove remaining tags
        {r'^\s+': u''}  # remove spaces at the beginning
    ]
    for rule in rules:
        for (k, v) in rule.items():
            regex = re.compile(k)
            text = regex.sub(v, text)
    text = text.rstrip()
    return text.lower()


def savePickle(data, picklefile):
    with open(picklefile, "wb") as f:
        pickle.dump(data, f)
    f.close()


def preprocessing_for_prediction(if_have_labels, df, target_category, model_ver):
    """ This function generates data, target_category name and feature_names list \
    for to be used in the prediction function later. All features are of string data type!"""
    target = None
    if if_have_labels == "yes":
        df = df.loc[:, ["name", "description", "summary", "original_tree", "brand", "provider",
                        target_category]]  # , target_category]]
        df.loc[:, target_category] = df.loc[:, target_category].astype(int)
        target = df.pop(target_category)
    else:
        df = df.loc[:, ["name", "description", "summary", "original_tree", "brand", "provider"]]  # , target_category]]

    # the features above are all the features defined in the 6_raw model
    if model_ver == "6_raw":
        feature_names = df.columns.tolist()
        print(f"Feature names are {feature_names}")
        print("Production mode running on trivial NAN -> "" preprocessing.")
        print(f"Before exiting step 1, the columns are {df.columns.tolist()}")
        print(f"""Check : the features have to be the following : \n 
        name, description, summary, original, tree, brand, provider""")

    elif model_ver == "6_full":
        df["combined_name_description"] = df.progress_apply(
            lambda row: str(row["name"]).lower() + str(row["description"]), axis=1)
        df["combined_name_description"] = df.progress_apply(lambda row: text_cleaner(str(
            row["combined_name_description"]).lower()), axis=1)
        df = df.rename(columns={"description": "cleaned_description"}, inplace=False)
        df = drop_if_exists(df, cols=["name"])
        df["cleaned_description"] = df.progress_apply(lambda row: text_cleaner(str(row["cleaned_description"]).lower()),
                                                      axis=1)
        df = df.loc[:,
             ["combined_name_description", "cleaned_description", "brand", "original_tree", "provider", "summary"]]

    feature_names = df.columns.tolist()
    features = replace_global_missing_features_with_empty(df)

    print(f"The 6 feature model has columns like {df.columns.tolist()}")

    return {"features": features, "target_category": target_category, "feature_names": feature_names,
            "target_series": target}

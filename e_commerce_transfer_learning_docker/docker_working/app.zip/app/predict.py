from tqdm import tqdm


def get_one_prediction(model, feature_row):
    one_prediction = model.predict(feature_row)[0].obj
    return one_prediction


def obtain_predictions_in_loop(logger, model, features, labels):
    incorrects = 0
    features = features.reset_index(drop=True)
    featurecount = features.shape[1]
    for i, feature_row in tqdm(features.iterrows(), total=features.shape[0]):
        prediction = get_one_prediction(model, feature_row)
        logger.info(f"Feature row {i} looks like this: \n")
        logger.info(f"{str(feature_row.values)}\n")
        logger.info(f"The corresponding prediction row {i} is: {prediction}\n")
        if labels is not None:
            label_i = labels.iloc[i]
            if prediction == label_i:
                answer = "correct"
                msg = f"The predicted tree path {prediction} is {answer}"
            else:
                incorrects += 1
                incorrects_ratio = incorrects, i
                answer = "INCORRECT"
                msg = f"{answer} tree path!"
                correctprint = f"The actual target value is: {label_i}, \n " \
                    f"running incorrects {incorrects_ratio} using only {featurecount} features!"
                print(correctprint)
                logger.info(correctprint)
        else:
            msg = f"The predicted tree path is : {prediction} and since we don't know the right answer, we continue "

        print(msg)
        logger.info(msg)
